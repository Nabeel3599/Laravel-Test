Get started:

- create your own repo (for example on www.github.com)
- change the origin to your own repo with `git remote set-url origin <remote_url>`
- change working directory to repo dir
- run `./setup.sh` (1 test should succeed and 3 should fail)
- open `app/Http/Controllers/EventsController.php for task 1-2`
- open `app/Http/Controllers/MenuController.php for task 3`
- open `database/migrations/2022_06_13_075211_create_cinema_schema.php for task 4`


Good luck! 🍀🚀
